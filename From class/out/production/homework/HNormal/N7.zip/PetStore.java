package HNormal.N7;

import HNormal.N7.dog.Dog;
import HNormal.N7.cat.Cat;

public class PetStore {
    public static void main(String[] args) {
        Dog dog = new Dog("Fido");
        Cat cat = new Cat("Whiskers");

        dog.eat();
        dog.play();
        dog.bark();

        cat.eat();
        cat.sleep();
        cat.meow();
    }
}