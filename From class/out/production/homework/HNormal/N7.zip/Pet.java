package HNormal.N7;

public interface Pet {
    void play();
}