package HNormal.N7.dog;

import HNormal.N7.Pet;
import HNormal.N7.Animal;

public class Dog extends Animal implements Pet {
    public Dog(String name) {
        super(name);
    }

    @Override
    public void eat() {
        System.out.println(name + " is eating dog food");
    }

    @Override
    public void play() {
        System.out.println(name + " is playing fetch");
    }

    public void bark() {
        System.out.println(name + " is barking");
    }
}