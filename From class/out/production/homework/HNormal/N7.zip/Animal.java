package HNormal.N7;

public class Animal {
    protected String name;

    public Animal(String name) {
        this.name = name;
    }

    public void eat() {
        System.out.println(name + " is eating");
    }

    protected void sleep() {
        System.out.println(name + " is sleeping");
    }
}