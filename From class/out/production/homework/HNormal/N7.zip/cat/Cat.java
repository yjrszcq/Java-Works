package HNormal.N7.cat;

import HNormal.N7.Animal;

public class Cat extends Animal {
    public Cat(String name) {
        super(name);
    }

    @Override
    public void eat() {
        System.out.println(name + " is eating cat food");
    }

    public void meow() {
        System.out.println(name + " is meowing");
    }
}